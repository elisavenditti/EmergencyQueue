#include <stdio.h>
#include <math.h>
#include "rngs.h"
#include "nodi.h"

int generatePassing(){
    //1 morte; 0 altrimenti
    SelectStream(10);
    if (Random() < 0.02)
        return (1);
    else
        return (0);
}


void arrivalAtProntoSoccorso(double current, int type, event_list_Priority event[], sum_server_Priority sum[], statoProntoSoccorso* statoProntoSoccorso, long* deathPS ){

    if(generatePassing()){        // non incremento nessuna variabile del pronto soccorso perch� ho un'uscita dal sistema
        (*deathPS) ++;
        return;
    }

    statoProntoSoccorso -> numberNode++;
    //printf("JOB IN PRONTO SOCCORSO: %d\n",statoProntoSoccorso -> numberNode);

    if (type == 2){
        statoProntoSoccorso -> number_Red_Node ++;
        //printf("Processing Pronto Soccorso arrival: RED\n");

    } else if (type == 1) {
        statoProntoSoccorso -> number_Yellow_Node++;
        //printf("Processing Pronto Soccorso arrival: YELLOW\n");
    }

    event[0].type = type;                                     //Memorizzo il tipo del job arrivato

    // se ho a disposizione almeno un server l'arrivo � servito immediatamente (in base al tipo)
    if (statoProntoSoccorso -> numberNode <= SERVERS_ProntoSoccorso) {

        double service  = GetService_ProntoSoccorso();
        int  s = FindOneProntoSoccorso(event);                  // Trovo il server disponibile da piu' tempo
        sum[s].service += service;                              // Aggiungo il tempo di servizio alla somma dei precedenti tempi di servizio per il server s
        sum[s].served++;                                        // Aumento il numero di jobs serviti al server s
        if (type) sum[s].servedCritical++;                      // Se l'evento � critico aumento il numero di jobs
                                                                // critici (gialli e rossi) per il server s
        event[s].t = current + service;                         // Genero il prossimo completamento al server s
        event[s].x = 1;                                         // Server s busy
        event[s].type = type;                                   // Memorizzo il tipo di completamento del prossimo servizio
        //printf("    entro in servizio nel servente (%d) libero, servizio a : %f\n", s, event[s].t);

    } else {
        // L'arrivo � aggiunto alla coda
        statoProntoSoccorso->numberQueue++;
        if (type == 2)
            statoProntoSoccorso -> number_Red_Queue++;
        else if (type == 1)
        statoProntoSoccorso -> number_Yellow_Queue++;
        // printf("    vado in coda\n");
    }
}


void completionAtProntoSoccorso (double current, event_list_Priority event[], sum_server_Priority sum[], statoProntoSoccorso* statoProntoSoccorso, statoAmbulance* statoAmbulanza, double* stopPS, int e){

    statoProntoSoccorso->numberNode --;                               // Diminuisco il numero di jobs nel sistema pronto soccorso
    statoProntoSoccorso->numberCompletion ++;                         // Aumento il numero di completamenti del sistema pronto soccorso

    //printf("Processing Pronto soccorso service: %d job rimanenti (%d nelle Ambulanze)\n", statoProntoSoccorso->numberNode, statoAmbulanza->numberNode);
    if(event[e].type == 2) {
        statoProntoSoccorso ->number_Red_Node --;
        statoProntoSoccorso ->number_Red_Completion ++;

    } else if (event[e].type == 1) {
        statoProntoSoccorso->number_Yellow_Node --;
        statoProntoSoccorso ->number_Yellow_Completion ++;
    }

    int s = e;
    int type = 0;                                                     // tipo di job che prender� in servizio

    // se ho coda prendo un job e lo servo (i job critici sono schedulati prima con il rischio di avere starvation
    // NB: poich� c'� coda solo il server che si � appena liberato � disponibile
    if (statoProntoSoccorso->numberNode >= SERVERS_ProntoSoccorso) {

        statoProntoSoccorso ->numberQueue --;
        // servo i job con pi� priorit�: codici rossi
        if (statoProntoSoccorso ->number_Red_Queue > 0) {
            type = 2;
            statoProntoSoccorso->number_Red_Queue  --;
            //printf("    Entra un paziente con codice rosso\n");
        } else if(statoProntoSoccorso ->number_Yellow_Queue > 0){
            type = 1;
            statoProntoSoccorso->number_Yellow_Queue  --;
            //printf( "    Entra un paziente con codice giallo\n");
        }

        double service   = GetService_ProntoSoccorso(type);
        sum[s].service += service;                                      // Aumento l'accumulated service times per il server s
        sum[s].served++;                                                // Aumento il numero di jobs serviti dal server s
        if (type) sum[s].servedCritical++;                              // Sto servendo un job critico (gialli e rossi): aumento il contatore.

        event[s].t = current + service;                                 // Aggiorno il prossimo completamento per il server s
        event[s].type = type;
        //printf("    servizio = %lf\n", event[s].t);
        //printf("[SMALTISCO IL JOB NEL SERVENTE %d]\n",s);
    } else
        event[s].x = 0;

    if (event[0].x == 0 && event[1].x==0 && statoProntoSoccorso->numberNode == 0){
        *stopPS = current;
    }
}

void SetupNode_ProntoSoccorso (event_list_Priority* event,sum_server_Priority* sum){

    for (int s = 0; s <  SERVERS_ProntoSoccorso + 2; s++) {
        event[s].t    = 0.0;
        if(s == 0 || s == 1)
            event[s].x = 1;        // indicano che gli arrivi al pronto soccorso sono abilitati
        else
            event[s].x = 0;
        event[s].type  = 0;
        sum[s].service = 0.0;
        sum[s].servedCritical = 0.0;
        sum[s].served = 0.0;
    }
}

 int FindOneProntoSoccorso(event_list_Priority event[])
/* -----------------------------------------------------
 * return the index of the available server idle longest
 * end index excluded
 * -----------------------------------------------------
 */
{
    int s;
    int i = 2; // Parto da due, i primi due indici rappresentano gli arrivi

    while (event[i].x == 1)       /* find the index of the first available */
        i++;                        /* (idle) server                         */
    s = i;

    while (i < SERVERS_ProntoSoccorso + 1) {         /* now, check the others to find which   */
        i++;                        /* has been idle longest                 */
        if ((event[i].x == 0) && (event[i].t < event[s].t))
        s = i;
    }
    return (s);
}


double GetService_ProntoSoccorso(){
    SelectStream(5);
    return(Exponential(25.0));
}



